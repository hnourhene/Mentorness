--- How many reservations were made for the year 2018 
SELECT COUNT(*) AS Total_Reservations_2018
FROM [Data Source].[dbo].[Hotel Reservation Dataset]
WHERE YEAR(arrival_date) = 2018;

