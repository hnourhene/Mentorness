---7. What is the highest and lowest lead time for reservations?  
SELECT 
    MAX(lead_time) AS Highest_Lead_Time,
    MIN(lead_time) AS Lowest_Lead_Time
FROM [Data Source].[dbo].[Hotel Reservation Dataset];
