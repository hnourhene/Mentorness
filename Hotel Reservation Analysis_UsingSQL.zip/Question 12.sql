---. How many reservations were made in each month of the year?
	SELECT 
    DATEPART(YEAR, arrival_date) AS Year,
    DATEPART(MONTH, arrival_date) AS Month,
    COUNT(*) AS Total_Reservations
FROM 
    [Data Source].[dbo].[Hotel Reservation Dataset 2]
GROUP BY 
    DATEPART(YEAR, arrival_date),
    DATEPART(MONTH, arrival_date)
ORDER BY 
    Year, Month;
