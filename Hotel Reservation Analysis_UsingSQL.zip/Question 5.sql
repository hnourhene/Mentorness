---What is the most commonly booked room type?  
SELECT top 1 room_type_reserved, COUNT(*) AS Total_Bookings
FROM [Data Source].[dbo].[Hotel Reservation Dataset]
GROUP BY room_type_reserved
ORDER BY Total_Bookings DESC;
