SELECT top 1
    market_segment_type,
    AVG(avg_price_per_room) AS Average_Price_Per_Room
FROM 
                [Data Source].[dbo].[Hotel Reservation Dataset ]

GROUP BY 
    market_segment_type
ORDER BY 
    Average_Price_Per_Room DESC

