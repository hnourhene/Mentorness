--  What is the average number of weekend nights for reservations involving children?   
SELECT AVG(no_of_weekend_nights) AS Average_Weekend_Nights_With_Children
FROM  [Data Source].[dbo].[Hotel Reservation Dataset]
WHERE no_of_children > 0;
