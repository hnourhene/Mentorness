---What is the most common market segment type for reservations?  
SELECT top 1  market_segment_type, COUNT(*) AS Total_Reservations
FROM [Data Source].[dbo].[Hotel Reservation Dataset]
GROUP BY market_segment_type
ORDER BY Total_Reservations DESC
