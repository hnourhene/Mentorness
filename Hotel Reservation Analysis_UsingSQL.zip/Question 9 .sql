SELECT COUNT(*) AS Confirmed_Reservations
FROM [Data Source].[dbo].[Hotel Reservation Dataset]
WHERE booking_status = 'Confirmed';
