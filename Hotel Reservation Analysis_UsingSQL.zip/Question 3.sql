---3. What is the average price per room for reservations involving children?  --
SELECT AVG (avg_price_per_room) AS Average_Price_Per_Room_With_Children
FROM [Hotel Reservation Dataset]
WHERE no_of_children > 0;

