---- 2. Which meal plan is the most popular among guests?  ---
SELECT TOP 1 type_of_meal_plan, COUNT(*) AS Total_Reservations
FROM [Hotel Reservation Dataset]
GROUP BY type_of_meal_plan
ORDER BY Total_Reservations DESC;
