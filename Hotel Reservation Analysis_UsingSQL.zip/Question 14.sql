

WITH ChildrenReservations AS (
    SELECT 
        room_type_reserved,
        COUNT(*) AS Reservation_Count
    FROM 
            [Data Source].[dbo].[Hotel Reservation Dataset ]
    WHERE 
        no_of_children > 0
    GROUP BY 
        room_type_reserved
)
SELECT top 1 
    CR.room_type_reserved,
    CR.Reservation_Count,
    AVG(HT.avg_price_per_room) AS Average_Price
FROM 
    ChildrenReservations CR
JOIN 
    [Data Source].[dbo].[Hotel Reservation Dataset ] HT ON CR.room_type_reserved = HT.room_type_reserved
GROUP BY 
    CR.room_type_reserved, CR.Reservation_Count
ORDER BY 
    CR.Reservation_Count DESC
