--  What is the total number of adults and children across all reservations?  
SELECT 
    SUM(no_of_adults) AS Total_Adults,
    SUM(no_of_children) AS Total_Children
FROM 
    [Data Source].[dbo].[Hotel Reservation Dataset];
