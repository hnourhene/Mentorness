---1. What is the total number of reservations in the dataset?  ---
SELECT COUNT(Booking_ID) AS Total_Reservations
FROM [Data Source].[dbo].[Hotel Reservation Dataset];


