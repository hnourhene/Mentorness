--How many reservations fall on a weekend (no_of_weekend_nights > 0)? 
SELECT COUNT(*) AS Total_Weekend_Reservations
FROM [Data Source].[dbo].[Hotel Reservation Dataset]
WHERE no_of_weekend_nights > 0;
